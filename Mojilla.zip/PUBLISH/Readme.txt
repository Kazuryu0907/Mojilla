# 使い方
- png.zipを`C:\Users\{ユーザー名}\AppData\Roaming\bakkesmod\bakkesmod\data\assets`に解凍してください
e.g. C:\Users\kazum\AppData\Roaming\bakkesmod\bakkesmod\data\assets\png\00a0.png
- 次にMojilla.dllを`C:\Users\{ユーザー名}\AppData\Roaming\bakkesmod\bakkesmod\plugins`に配置してください
- 後は`C:\Users\kazum\AppData\Roaming\bakkesmod\bakkesmod\cfg\plugins.cfg`に`plugin load Mojilla`を追記してください
- 連絡はtwitterまで
